<!DOCTYPE html>
<html>
<head>
  <title>Feedback Form</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <div class="container">
    <h1>Feedback Form</h1>
    
    <form id="feedbackForm" method="post" action="index.php">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>
      
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>
      
      <label for="message">Message:</label>
      <textarea id="message" name="message" required></textarea>
      
      <button type="submit">Submit</button>
    </form>
  </div>
  
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="script.js"></script>
</body>
</html>

<!-- This Code Written By The Tirth Koradiya -->


<?php
// Get the user input from the form
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// Establish a database connection (replace db_host, db_username, db_password, and db_name with your actual database credentials)
$connection = new mysqli('db_host', 'db_username', 'db_password', 'db_name');

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Insert the feedback data into the database
$query = "INSERT INTO message_table(name, email, message) VALUES ('$name', '$email', '$message')";
if ($connection->query($query) === TRUE) {
    echo "Feedback submitted successfully!";
} else {
    echo "Error: " . $query . "<br>" . $connection->error;
}

// Close the database connection
$connection->close();
?>